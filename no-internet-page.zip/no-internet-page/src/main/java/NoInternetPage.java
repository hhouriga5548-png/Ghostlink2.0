import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.net.URI;

/**
 * NoInternetPage.java
 * Mimics the Chrome "No Internet" error screen.
 * SECRET: Click the top-right corner (50x50 px zone) to open google.com in your browser.
 */
public class NoInternetPage extends JFrame {

    private static final int SECRET_ZONE_SIZE = 50;
    private static final String REDIRECT_URL  = "https://www.google.com";

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new NoInternetPage().setVisible(true));
    }

    public NoInternetPage() {
        setTitle("No Internet");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setMinimumSize(new Dimension(600, 400));
        setLocationRelativeTo(null);

        NoInternetPanel panel = new NoInternetPanel();
        add(panel);

        panel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int x = e.getX();
                int y = e.getY();
                int w = panel.getWidth();

                if (x >= w - SECRET_ZONE_SIZE && y <= SECRET_ZONE_SIZE) {
                    openBrowser(REDIRECT_URL);
                }
            }
        });
    }

    private void openBrowser(String url) {
        try {
            Desktop.getDesktop().browse(new URI(url));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                "Could not open browser:\n" + ex.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    static class NoInternetPanel extends JPanel {

        private static final Color BG_COLOR   = new Color(255, 255, 255);
        private static final Color TEXT_COLOR = new Color(84,  84,  84);
        private static final Color DINO_COLOR = new Color(84,  84,  84);

        private boolean eyeOpen = true;
        private Timer blinkTimer;

        NoInternetPanel() {
            setBackground(BG_COLOR);

            blinkTimer = new Timer(3000, e -> {
                eyeOpen = !eyeOpen;
                repaint();
                if (!eyeOpen) {
                    Timer reopenTimer = new Timer(150, ev -> {
                        eyeOpen = true;
                        repaint();
                    });
                    reopenTimer.setRepeats(false);
                    reopenTimer.start();
                }
            });
            blinkTimer.start();
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int cx = getWidth()  / 2;
            int cy = getHeight() / 2;

            drawDino(g2, cx - 200, cy - 60);

            g2.setColor(TEXT_COLOR);
            g2.setFont(new Font("Arial", Font.BOLD, 24));
            String heading = "No internet";
            FontMetrics fmH = g2.getFontMetrics();
            int headingX = cx - fmH.stringWidth(heading) / 2 + 80;
            g2.drawString(heading, headingX, cy - 20);

            g2.setFont(new Font("Arial", Font.PLAIN, 14));
            String sub1 = "Try:";
            String sub2 = "\u2022  Checking the network cables, modem, and router";
            String sub3 = "\u2022  Reconnecting to Wi-Fi";
            int subX = cx - 100 + 80;
            g2.drawString(sub1, subX, cy + 10);
            g2.drawString(sub2, subX, cy + 32);
            g2.drawString(sub3, subX, cy + 52);

            g2.setFont(new Font("Arial", Font.PLAIN, 12));
            g2.setColor(new Color(130, 130, 130));
            g2.drawString("ERR_INTERNET_DISCONNECTED", subX, cy + 82);

            drawReloadButton(g2, subX, cy + 100);

            g2.setColor(new Color(200, 200, 200));
            g2.setStroke(new BasicStroke(2f));
            g2.drawLine(0, cy + 130, getWidth(), cy + 130);

            g2.dispose();
        }

        private void drawReloadButton(Graphics2D g2, int x, int y) {
            g2.setColor(new Color(26, 115, 232));
            g2.setFont(new Font("Arial", Font.PLAIN, 13));
            FontMetrics fm = g2.getFontMetrics();
            String label = "Reload";
            int bw = fm.stringWidth(label) + 32;
            int bh = 32;
            RoundRectangle2D btn = new RoundRectangle2D.Float(x, y, bw, bh, 4, 4);
            g2.fill(btn);
            g2.setColor(Color.WHITE);
            g2.drawString(label, x + 16, y + bh / 2 + fm.getAscent() / 2 - 1);
        }

        private void drawDino(Graphics2D g2, int ox, int oy) {
            g2.setColor(DINO_COLOR);
            float s = 2.2f;

            fillRect(g2, ox, oy, 22, 22, s);
            fillRect(g2, ox + (int)(4*s), oy - (int)(10*s), 14, 12, s);
            fillRect(g2, ox + (int)(4*s), oy - (int)(22*s), 20, 12, s);
            fillRect(g2, ox + (int)(18*s), oy - (int)(18*s), 6, 6, s);

            if (eyeOpen) {
                g2.setColor(BG_COLOR);
                fillRect(g2, ox + (int)(18*s), oy - (int)(20*s), 4, 4, s);
            }
            g2.setColor(DINO_COLOR);

            fillRect(g2, ox - (int)(8*s), oy + (int)(12*s), 10, 8, s);
            fillRect(g2, ox - (int)(16*s), oy + (int)(16*s), 10, 4, s);
            fillRect(g2, ox + (int)(10*s), oy + (int)(20*s), 6, 10, s);
            fillRect(g2, ox + (int)(10*s), oy + (int)(28*s), 8, 4, s);
            fillRect(g2, ox + (int)(2*s), oy + (int)(20*s), 6, 10, s);
            fillRect(g2, ox - (int)(2*s), oy + (int)(28*s), 8, 4, s);
            fillRect(g2, ox + (int)(18*s), oy - (int)(4*s), 6, 4, s);
        }

        private void fillRect(Graphics2D g2, int x, int y, int w, int h, float s) {
            g2.fillRect(x, y, (int)(w * s), (int)(h * s));
        }
    }
}
