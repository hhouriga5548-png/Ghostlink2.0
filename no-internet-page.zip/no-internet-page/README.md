# 🦕 No Internet Page

A Java Swing app that mimics Chrome's "No Internet" error screen — complete with a blinking T-Rex dinosaur.

> **Secret:** Click the **top-right corner** of the window to be redirected to the real site.

![Java](https://img.shields.io/badge/Java-8%2B-orange?logo=java)
![License](https://img.shields.io/badge/license-MIT-blue)

---

## 📸 Preview

The app renders a pixel-art T-Rex, error message, bullet tips, and a fake Reload button — identical to Chrome's offline page.

---

## 🚀 Getting Started

### Requirements
- Java 8 or higher

### Run without building

```bash
javac src/main/java/NoInternetPage.java -d out
java -cp out NoInternetPage
```

### Build & run with Maven

```bash
mvn package
java -jar target/no-internet-page-1.0.jar
```

### Build & run with the shell script

```bash
chmod +x run.sh
./run.sh
```

---

## 🕹️ How to Use

| Action | Result |
|---|---|
| Launch the app | Chrome-style No Internet screen appears |
| Click top-right corner (50×50 px) | Opens `https://www.google.com` in your browser |
| Click "Reload" button | Nothing (it's fake — intentional) |

---

## ⚙️ Configuration

Edit these two constants at the top of `NoInternetPage.java`:

```java
private static final int    SECRET_ZONE_SIZE = 50;            // size of secret click area (px)
private static final String REDIRECT_URL     = "https://www.google.com"; // where to redirect
```

---

## 📁 Project Structure

```
no-internet-page/
├── src/
│   └── main/
│       └── java/
│           └── NoInternetPage.java   # Main source file
├── .github/
│   └── workflows/
│       └── build.yml                 # GitHub Actions CI
├── pom.xml                           # Maven build file
├── run.sh                            # Quick run script
└── README.md
```

---

## 📄 License

MIT — do whatever you want with it.
