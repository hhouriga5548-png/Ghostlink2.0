#!/usr/bin/env bash
# run.sh — compile and launch NoInternetPage without Maven

set -e

SRC="src/main/java/NoInternetPage.java"
OUT="out"

echo "Compiling..."
mkdir -p "$OUT"
javac "$SRC" -d "$OUT"

echo "Launching..."
java -cp "$OUT" NoInternetPage
